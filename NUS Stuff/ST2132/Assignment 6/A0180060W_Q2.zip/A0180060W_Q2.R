free = 10
pchisq(18.31/2, df=free, lower.tail=FALSE)  
pchisq(18.31/4, df=free, lower.tail=FALSE) 


# library(OptSig)

# Power.Chisq(ncp = 2, df = free, alpha = 0.05)
#                 # 0.1207775

# Power.Chisq(ncp = 4, df = free, alpha = 0.05)
#                 # 0.2148945